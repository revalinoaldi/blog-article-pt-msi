<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard Page')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <div class="max-w-sm bg-white border border-gray-200 rounded-lg shadow ">
                        <?php
                            $routeUrl = Auth::check() ? "article.show" : "article-detail";
                        ?>
                        <a href="<?php echo e(route($routeUrl, $article['slug'])); ?>">
                            <?php
                            $validUrl = filter_var($article['image'], FILTER_VALIDATE_URL) ? $article['image'] : Storage::url(''.$article['image']);
                            ?>
                            <img class="rounded-t-lg" src="<?php echo e($validUrl); ?>" alt="" />
                        </a>
                        <div class="p-5">
                            <a href="<?php echo e(route($routeUrl, $article['slug'])); ?>">
                                <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 "><?php echo e($article['title']); ?></h5>
                            </a>
                            <div class="text-gray-600 text-sm mb-4">
                                Created on <span class="font-bold"><?php echo e(\Carbon\Carbon::parse($article['created_at'])->format('F d, Y')); ?></span> <br>
                                Publish on <span class="font-bold"><?php echo e(@$article['is_publish'] ? \Carbon\Carbon::parse($article['publish_at'])->format('F d, Y') : "- (Not published)"); ?></span><br> by
                                <span class="font-bold"><?php echo e($article['author']['name']); ?></span>
                            </div>
                            <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">
                                <?php echo e($article['excerpt']); ?>

                            </p>
                            <a href="<?php echo e(route($routeUrl, $article['slug'])); ?>" class="inline-flex items-center px-3 py-2 text-sm font-medium text-center text-white bg-blue-700 rounded-lg hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                Read more
                                <svg aria-hidden="true" class="w-4 h-4 ml-2 -mr-1" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class="flex justify-end mr-3 mt-3">
                <?php echo e($articles->links()); ?>

            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\article-blog\resources\views/dashboard.blade.php ENDPATH**/ ?>