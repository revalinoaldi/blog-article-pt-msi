## How to installs

-   git clone repo url
-   cp .env.example .env
-   setting your database configuration
-   in terminal > composer install
-   in terminal > npm install
-   in terminal > php artisan key:generate --ansi
-   in terminal > php artisan migrate
-   in terminal > php artisan config:cache
-   in terminal > php artisan route:cache
-   in terminal > npm run dev
-   in terminal > php artisan serve

access manual -> http://youapp.test/
file gzip -> [Source Code](https://drive.google.com/file/d/11hqUcGdVeglV_oG6qhY1_STJ_ucm1t-V/view?usp=sharing).
